logger::log_appender(function(...) NULL, namespace = "teal.modules.clinical")
